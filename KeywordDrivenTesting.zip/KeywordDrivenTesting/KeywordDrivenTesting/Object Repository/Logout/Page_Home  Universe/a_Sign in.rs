<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign in</name>
   <tag></tag>
   <elementGuidId>07105a57-9594-4610-880c-77010df83d2c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.header__link.header__link--secondary.button</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Sign in')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0d293959-2790-45eb-9c73-e194045bee3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header__link header__link--secondary button</value>
      <webElementGuid>acf33f98-0b6f-45f2-b613-8b8700e8bebd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/sign-in</value>
      <webElementGuid>d5a5035a-4eda-46bc-8ce5-ad7089c75ed0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign in</value>
      <webElementGuid>38cf5c82-a496-4429-98ff-307d37b974b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[@class=&quot;header&quot;]/nav[@class=&quot;container header__nav&quot;]/ul[@class=&quot;header__menu&quot;]/li[@class=&quot;header__item&quot;]/a[@class=&quot;header__link header__link--secondary button&quot;]</value>
      <webElementGuid>54d87646-071c-40a4-b65a-171e6aecb252</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Sign in')]</value>
      <webElementGuid>b985f220-8f1f-472e-86e7-ccf4d511782f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/preceding::a[1]</value>
      <webElementGuid>66dc6910-de51-4f17-bb59-8898cde7f465</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create a World!'])[1]/preceding::a[2]</value>
      <webElementGuid>48826bbd-f4c4-47e7-bd0b-986af78365e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign in']/parent::*</value>
      <webElementGuid>4134f245-c273-4be9-8ed7-6dbe455b69e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/sign-in')]</value>
      <webElementGuid>d18c8e6a-ea15-4194-8730-c8e8d2682c05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a</value>
      <webElementGuid>515a304c-14e4-4ea2-a063-c61dd5222f87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/sign-in' and (text() = 'Sign in' or . = 'Sign in')]</value>
      <webElementGuid>6b4f6a06-3695-4acd-9509-6b6093eb5ec0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
