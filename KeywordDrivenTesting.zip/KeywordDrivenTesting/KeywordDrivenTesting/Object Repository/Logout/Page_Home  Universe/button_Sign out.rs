<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Sign out</name>
   <tag></tag>
   <elementGuidId>4ad11f8d-6101-43fc-8997-734a509202a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.dropdown__link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>42853c26-f3e7-4e67-83fa-f1b05bd56824</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown__link</value>
      <webElementGuid>ffe83d74-ddfa-4df4-994a-39cd5c44b169</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign out</value>
      <webElementGuid>8d331ede-566e-4132-8f1f-df45ce4f2ab5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[@class=&quot;header&quot;]/nav[@class=&quot;container header__nav&quot;]/ul[@class=&quot;header__menu&quot;]/li[@class=&quot;header__item&quot;]/div[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown__menu&quot;]/li[@class=&quot;dropdown__item&quot;]/form[1]/button[@class=&quot;dropdown__link&quot;]</value>
      <webElementGuid>16b3271b-572a-4d9e-a17b-c1c9c7e0aad0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::button[1]</value>
      <webElementGuid>94b79c22-4223-4848-b8e6-6889059f13cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My profile'])[1]/following::button[1]</value>
      <webElementGuid>8a1b7afd-b6e5-4960-9866-c6731efc2f43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TITLE'])[1]/preceding::button[1]</value>
      <webElementGuid>9e57006f-f789-4fe7-b709-8e794e7f8b23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read more'])[1]/preceding::button[1]</value>
      <webElementGuid>750e79bc-8d74-4576-bf5f-22444ddbfe2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign out']/parent::*</value>
      <webElementGuid>5874b2fd-5855-4940-9484-085a12052be5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/button</value>
      <webElementGuid>df5e4fe3-7203-46bf-b381-12438dcb099e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Sign out' or . = 'Sign out')]</value>
      <webElementGuid>4bf4188a-e665-46b3-b6a4-32d9da4ace6a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
