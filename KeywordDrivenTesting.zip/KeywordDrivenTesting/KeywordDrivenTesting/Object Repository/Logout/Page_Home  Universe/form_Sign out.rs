<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Sign out</name>
   <tag></tag>
   <elementGuidId>8286e3aa-81bd-4e82-8374-fe40e2681d44</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='/sign-out']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>53ef1ed8-5e8a-432c-b10e-b2de51c9dcfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>f80bb898-d950-4cfd-b52a-5df6d8e1bcd1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>/sign-out</value>
      <webElementGuid>07e7a3de-1ea5-47c3-93f6-e37f8ec31d3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                        
                                        Sign out
                                    </value>
      <webElementGuid>8074f2ca-9d6b-4183-81c1-5792ed8bcf02</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[@class=&quot;header&quot;]/nav[@class=&quot;container header__nav&quot;]/ul[@class=&quot;header__menu&quot;]/li[@class=&quot;header__item&quot;]/div[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown__menu&quot;]/li[@class=&quot;dropdown__item&quot;]/form[1]</value>
      <webElementGuid>4e604f1d-917b-400e-b3c8-f02636e78aad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='/sign-out']</value>
      <webElementGuid>422c84b4-06da-438d-9bcb-5a246a6d6a3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::form[1]</value>
      <webElementGuid>7b0b45bc-260a-492a-a3bb-172705b86be2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My profile'])[1]/following::form[1]</value>
      <webElementGuid>1da9fc37-9c1c-4807-962d-6519bc6d5a38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TITLE'])[1]/preceding::form[1]</value>
      <webElementGuid>d769219d-ba93-4190-8c1b-d87f39a65d7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>c1f49300-2b4c-4a2f-b796-876f2317bd9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
                                        
                                        Sign out
                                    ' or . = '
                                        
                                        Sign out
                                    ')]</value>
      <webElementGuid>72d4d7d0-429e-49fa-bc0b-457d61d95670</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
