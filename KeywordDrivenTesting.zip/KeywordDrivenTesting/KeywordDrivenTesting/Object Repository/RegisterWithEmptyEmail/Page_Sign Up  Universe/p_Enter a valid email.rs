<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Enter a valid email</name>
   <tag></tag>
   <elementGuidId>5bd3b3ca-4e1c-447d-bb41-c7637b48c1a4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.form__row.form__row--error > p.form__feedback</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>26bb4407-ae3e-4ccb-8660-c271aedecdd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form__feedback</value>
      <webElementGuid>70d813dd-465a-4f89-a934-a7c5bf40f745</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Enter a valid email</value>
      <webElementGuid>8b8e2126-6196-4336-99d6-fd9322b8715c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;form-wrapper&quot;]/main[@class=&quot;main&quot;]/div[@class=&quot;container&quot;]/form[@class=&quot;sign-up-form form&quot;]/div[@class=&quot;form__row form__row--error&quot;]/p[@class=&quot;form__feedback&quot;]</value>
      <webElementGuid>fde0a604-0d38-4c18-b12a-5e125d06bbf0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[1]/following::p[1]</value>
      <webElementGuid>c7deeb59-5e09-430f-97e7-df8979184b68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last name'])[1]/following::p[2]</value>
      <webElementGuid>3f6a9a99-f55d-46f1-a6cd-60f159639f4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/preceding::p[1]</value>
      <webElementGuid>5b5e19f5-03fc-4361-8b0c-dd09bb2e3e0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm password'])[1]/preceding::p[2]</value>
      <webElementGuid>b35624c6-78a2-4e56-a1ae-99b58bb67bd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Enter a valid email']/parent::*</value>
      <webElementGuid>e54ff593-6a50-4839-be00-be51fe74706a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/p</value>
      <webElementGuid>dd19e4ad-7d7b-47ee-995a-0135492b22fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Enter a valid email' or . = 'Enter a valid email')]</value>
      <webElementGuid>0484f0b4-c038-4a3f-92e5-b227ff50c93e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
