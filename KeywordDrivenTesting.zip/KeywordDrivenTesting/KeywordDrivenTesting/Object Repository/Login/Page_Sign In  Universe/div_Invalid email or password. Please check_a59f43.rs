<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Invalid email or password. Please check_a59f43</name>
   <tag></tag>
   <elementGuidId>fa4533e6-cf64-4823-817f-cca523b63e96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in failed!'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.alert__description</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>41cf54ca-8ec7-4ff5-a0df-5ef0654f53f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>alert__description</value>
      <webElementGuid>d4044a4a-42f6-499e-9d2d-679988cb4dce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Invalid email or password. Please check your input and try again.</value>
      <webElementGuid>6df78bcb-01dc-4305-b47c-846f4c345b6c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;alert alert--visible&quot;]/div[@class=&quot;alert__inner&quot;]/div[@class=&quot;alert__description&quot;]</value>
      <webElementGuid>e8e89dff-390a-4b45-aaab-b87d956e0ab1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in failed!'])[1]/following::div[1]</value>
      <webElementGuid>6d1137a5-1dd2-433d-ba05-42ca7f5c28e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/following::div[4]</value>
      <webElementGuid>7b70bf52-01f8-42d0-bdc8-87bef8684cc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OK'])[1]/preceding::div[1]</value>
      <webElementGuid>b71ffe3a-936d-4452-a5cc-3d97076cd04b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Invalid email or password. Please check your input and try again.']/parent::*</value>
      <webElementGuid>e084b77f-fde0-4434-8b23-27cb30971308</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]</value>
      <webElementGuid>2fd74f88-fd8b-4e71-b25e-b2a3ea76d652</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Invalid email or password. Please check your input and try again.' or . = 'Invalid email or password. Please check your input and try again.')]</value>
      <webElementGuid>df301516-8ef2-4e92-ac47-b3875f6edc87</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
