<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Sign In                            Ema_6c7101</name>
   <tag></tag>
   <elementGuidId>ee3d537b-e6c9-4cbb-b63a-16178c680e33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form.sign-in-form.form</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>340ed14f-08bd-473f-a320-e7d0b3921c5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sign-in-form form</value>
      <webElementGuid>5daa3839-e23b-4e55-ba39-f7be98ac5759</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>de9a3e66-83fb-4cf2-8578-1f45e2baae04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    </value>
      <webElementGuid>52246170-50bb-4d87-ae5d-7fbd4d032433</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;form-wrapper&quot;]/main[@class=&quot;main&quot;]/div[@class=&quot;container&quot;]/form[@class=&quot;sign-in-form form&quot;]</value>
      <webElementGuid>5dfd7bf9-33c5-4107-9f57-64ff1e328b98</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='']</value>
      <webElementGuid>5310eb70-8085-4792-baf7-8fadb07ed430</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>da7fdb78-b620-4ea9-b56a-0a192a394162</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    ' or . = '
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    ')]</value>
      <webElementGuid>4567f4dc-8faf-43a5-8ec3-6c642d6c2d7c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
