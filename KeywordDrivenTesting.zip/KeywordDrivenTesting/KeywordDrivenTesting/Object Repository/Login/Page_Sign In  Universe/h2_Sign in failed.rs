<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Sign in failed</name>
   <tag></tag>
   <elementGuidId>d3915ae9-7a20-4193-bcb0-20fb18dd230e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/following::h2[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.alert__heading</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>81b20f87-6b84-4073-9ede-ab99d92bfa2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>alert__heading</value>
      <webElementGuid>ad132694-3fd4-4e3f-933b-df19c39c8dc8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign in failed!</value>
      <webElementGuid>36fd7afa-6f77-431a-b9ca-0eb39eadccba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;alert alert--visible&quot;]/div[@class=&quot;alert__inner&quot;]/div[@class=&quot;alert__header&quot;]/h2[@class=&quot;alert__heading&quot;]</value>
      <webElementGuid>0394bde1-4d1c-44ee-9870-79301c6e70d2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/following::h2[1]</value>
      <webElementGuid>ac4a1524-4704-4f8a-924e-0493ec5953c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New to Universe?'])[1]/following::h2[1]</value>
      <webElementGuid>63c5b65b-0698-4d2e-8e02-ca8e9fc24b6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Invalid email or password. Please check your input and try again.'])[1]/preceding::h2[1]</value>
      <webElementGuid>b142af09-0c1e-44c5-9b60-dfbfbe7acdf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OK'])[1]/preceding::h2[1]</value>
      <webElementGuid>fe2a3a58-361c-40fc-bbeb-5344b4b16ac9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign in failed!']/parent::*</value>
      <webElementGuid>0e423523-374a-4ed5-bb69-04f3315e1017</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>f247a42b-755b-4c57-b0fc-e708c8c51480</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Sign in failed!' or . = 'Sign in failed!')]</value>
      <webElementGuid>0e5071e7-a243-48b6-8c8c-b01dc497fc4e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
