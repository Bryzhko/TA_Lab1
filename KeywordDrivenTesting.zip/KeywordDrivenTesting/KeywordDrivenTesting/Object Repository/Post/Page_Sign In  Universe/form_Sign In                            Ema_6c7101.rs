<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Sign In                            Ema_6c7101</name>
   <tag></tag>
   <elementGuidId>86ce32bf-d603-4c53-b0ca-c4b0cffdb445</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form.sign-in-form.form</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>6c5b01cc-17b5-43dc-86de-748338a64470</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sign-in-form form</value>
      <webElementGuid>395be509-3b7e-4038-bf37-5febda455f53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>c5ffb5c4-ffc0-44b2-a86e-e44eadadeb97</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    </value>
      <webElementGuid>f9f5fda3-9184-49b1-88b3-09431411ef73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;form-wrapper&quot;]/main[@class=&quot;main&quot;]/div[@class=&quot;container&quot;]/form[@class=&quot;sign-in-form form&quot;]</value>
      <webElementGuid>8c8d71fb-c50a-487d-8f97-e7e1bdf92ea4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='']</value>
      <webElementGuid>ee2a946c-3ee2-436f-8859-2c1faf2b7abf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>2a3eda58-72be-44ad-be1c-b47541756689</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    ' or . = '
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    ')]</value>
      <webElementGuid>f4a5ad8c-9070-477e-832a-ee5f04747352</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
