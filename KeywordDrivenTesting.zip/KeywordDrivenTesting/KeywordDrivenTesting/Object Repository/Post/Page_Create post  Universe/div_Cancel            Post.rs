<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Cancel            Post</name>
   <tag></tag>
   <elementGuidId>2243a281-a715-4e59-8ce6-71c43c999f15</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.post-form__footer.form__footer</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Abracadabra3535'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>61d91d50-015d-457b-a115-14bfb6a28fab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>post-form__footer form__footer</value>
      <webElementGuid>95eedea2-6e79-4c38-9ac9-72b4b5cd1fa3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Cancel
            Post
        </value>
      <webElementGuid>901da6aa-61ab-4e74-8f1c-ad815f1588ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container container--flex&quot;]/form[@class=&quot;post-creating-form post-form form&quot;]/div[@class=&quot;post-form__footer form__footer&quot;]</value>
      <webElementGuid>7ca8deb4-a10a-4cb8-8c94-3e9a59c5999b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Abracadabra3535'])[1]/following::div[2]</value>
      <webElementGuid>cec6130b-3f09-4c98-b93a-8369255e56c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/following::div[4]</value>
      <webElementGuid>fd1be2c8-bce4-49b1-a816-fbf326c9abca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[3]</value>
      <webElementGuid>421bec04-3690-49a7-97cd-46138a8adc42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            Cancel
            Post
        ' or . = '
            Cancel
            Post
        ')]</value>
      <webElementGuid>9ebeb3a9-5cae-40f4-b3bd-7920ffeffef3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
