<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Abracadabra3535                       _f035d4</name>
   <tag></tag>
   <elementGuidId>175d3844-963c-4214-925c-a06e460c47b0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form.post-creating-form.post-form.form</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='/posts']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>f7118828-d019-4995-aab2-9957e4445bfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>post-creating-form post-form form</value>
      <webElementGuid>a1c638e3-d5da-477e-8dd3-8079c7c08876</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>399a5d43-19eb-4f1b-8036-1b5a196f241f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>/posts</value>
      <webElementGuid>10da52f0-b7f0-4e2f-b3cc-e6f7e4b77798</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
        
        
            Abracadabra3535
            
        
        
            
            
        
        
            Cancel
            Post
        
    </value>
      <webElementGuid>957b08a3-5e14-40e6-8553-3f27cf7d410a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container container--flex&quot;]/form[@class=&quot;post-creating-form post-form form&quot;]</value>
      <webElementGuid>5ff1bffe-8a22-43b1-a647-7337ba6dae49</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='/posts']</value>
      <webElementGuid>ec02407c-0413-477f-8132-0108a5cf0903</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/following::form[1]</value>
      <webElementGuid>aa1c8ad0-87ba-4710-9431-b158f6af1c00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::form[2]</value>
      <webElementGuid>3ac3f36e-980d-44b2-ba2a-3712059047c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/form</value>
      <webElementGuid>f96c002a-e06b-4f5b-977e-170f06448fa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
        
        
        
        
            Abracadabra3535
            
        
        
            
            
        
        
            Cancel
            Post
        
    ' or . = '
        
        
        
        
            Abracadabra3535
            
        
        
            
            
        
        
            Cancel
            Post
        
    ')]</value>
      <webElementGuid>522d1d51-e038-42e1-9522-3ed8ce5a4a12</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
