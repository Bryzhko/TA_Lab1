<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Cancel            Post</name>
   <tag></tag>
   <elementGuidId>ec544b8b-2f32-4208-816f-00b35372c603</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form.post-creating-form.post-form.form</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='/posts']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>f519be7a-d5e0-4b45-978d-36a679fbd9d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>post-creating-form post-form form</value>
      <webElementGuid>713d0782-eb16-43ae-bbd3-748d0e1eced5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>fa1ddd4f-ba75-4c39-a873-e960492dee09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>/posts</value>
      <webElementGuid>16c6e09e-acad-4748-8881-3d7f0ab938bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
        
        
            
            
        
        
            
            
        
        
            Cancel
            Post
        
    </value>
      <webElementGuid>e6cdd864-7645-4ec1-800b-83e7166d001b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container container--flex&quot;]/form[@class=&quot;post-creating-form post-form form&quot;]</value>
      <webElementGuid>b653a70d-8299-4e69-8fe3-a88db7246c42</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='/posts']</value>
      <webElementGuid>6818149c-e0f1-4157-9bbe-8f9f51fa243f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/following::form[1]</value>
      <webElementGuid>acb3590f-3660-428e-bde5-50a2843e8f66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::form[2]</value>
      <webElementGuid>50663428-9f1d-4f48-add5-dffa985223df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/form</value>
      <webElementGuid>6aba1074-cddb-4bf0-a52c-af6e46d32f5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
        
        
        
        
            
            
        
        
            
            
        
        
            Cancel
            Post
        
    ' or . = '
        
        
        
        
            
            
        
        
            
            
        
        
            Cancel
            Post
        
    ')]</value>
      <webElementGuid>60ee591e-8ced-4f60-8c55-333b6f9d7249</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
