<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign up</name>
   <tag></tag>
   <elementGuidId>adf8dfc5-d0ed-43f3-b692-dee40637b426</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.header__link.header__link--primary.button</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Sign up')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cb008d02-35e5-4e0c-a4b3-f6962b2180ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header__link header__link--primary button</value>
      <webElementGuid>675e3b77-c87b-4990-95b7-22e380d42b26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/sign-up</value>
      <webElementGuid>2f415d39-436e-4f54-9fdf-974a96ebe8ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign up</value>
      <webElementGuid>d19db4d8-0290-4ca2-aac2-b2934a53de4c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[@class=&quot;header&quot;]/nav[@class=&quot;container header__nav&quot;]/ul[@class=&quot;header__menu&quot;]/li[@class=&quot;header__item&quot;]/a[@class=&quot;header__link header__link--primary button&quot;]</value>
      <webElementGuid>e903e774-e62c-4d87-8cfc-0b26178e5e4f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Sign up')]</value>
      <webElementGuid>7cc00c12-5a31-4ef3-b7a6-df3e90330a3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::a[1]</value>
      <webElementGuid>ba14ed3b-b4d2-47d2-8dcb-d3ca85e1268c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create a World!'])[1]/preceding::a[1]</value>
      <webElementGuid>4b4c9d1c-efdb-45b6-b790-ee40dbb54d47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[2]/preceding::a[1]</value>
      <webElementGuid>f3a71fdb-a954-4cc5-8df3-6ac233da4db9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign up']/parent::*</value>
      <webElementGuid>7d846cfb-cdd5-49ec-85d4-180e39c71832</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/sign-up')]</value>
      <webElementGuid>20de2587-3222-4a5d-956d-6069cc3392ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a</value>
      <webElementGuid>b280817b-b88f-4225-98e2-91ee356a8353</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/sign-up' and (text() = 'Sign up' or . = 'Sign up')]</value>
      <webElementGuid>16ebfd8c-c5cf-462a-bb98-4a2bc9769642</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
