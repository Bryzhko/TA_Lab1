<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Update information</name>
   <tag></tag>
   <elementGuidId>15189d9c-f4d0-4407-8bb6-94c59d4564ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Website'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.button.button--fluid.button--primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>103a9e9b-2950-40ce-b399-c689fef4ed7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button button--fluid button--primary</value>
      <webElementGuid>9d406805-c220-4183-aff3-d90677853c43</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Update information</value>
      <webElementGuid>fa1862b2-a94f-481e-a1ce-bcba71ea0a5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container container--flex&quot;]/form[@class=&quot;account-form form&quot;]/div[@class=&quot;form__footer&quot;]/button[@class=&quot;button button--fluid button--primary&quot;]</value>
      <webElementGuid>16204cc8-9867-4161-a045-d5a21ab992a5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Website'])[1]/following::button[1]</value>
      <webElementGuid>c3883d63-17ac-4a75-b507-4598c8c3b47e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/following::button[1]</value>
      <webElementGuid>f5458a12-58e9-4212-97f7-9632f828e9d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/preceding::button[1]</value>
      <webElementGuid>6d4f34ff-77b5-40ac-8cae-8d319897ac83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sample content goes here.'])[1]/preceding::button[2]</value>
      <webElementGuid>5e5cbf47-bdfa-4db9-8c08-e50697ac5611</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Update information']/parent::*</value>
      <webElementGuid>ffbf1838-3473-4f91-a7ad-64d606044c84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/button</value>
      <webElementGuid>eb4b022d-e7c3-49dd-9579-5eb0ae39fb01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Update information' or . = 'Update information')]</value>
      <webElementGuid>879663bb-1faf-4be2-9069-a3ab39e28152</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
