<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Account                                _66f632</name>
   <tag></tag>
   <elementGuidId>01fbd2cf-293f-44fa-90ce-e04e5ae5cc2e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.container.container--flex</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>084bffd3-8098-4818-b6a8-ed84a27f6886</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container container--flex</value>
      <webElementGuid>7d2608c7-f416-490e-8e31-d3dc874d5bf4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
        
        
            Account
            
        
        
            
                First name
                
                
            
            
                Last name
                
                
            
        
        
            Email
            
            
        
        
            Gender
            
                
                Male
                Female
            
            
        
        
            Birthday
            
            
        
        
            Address
            
            
        
        
            Website
            
            
        
        
            Update information
        
    
</value>
      <webElementGuid>678be38e-1ae8-4e29-bfcc-de33dc500335</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container container--flex&quot;]</value>
      <webElementGuid>3e209bad-a8b7-4400-bd5c-287ada11a327</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/following::div[1]</value>
      <webElementGuid>18f9189c-0625-4ee1-89a2-ffddee70623f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::div[1]</value>
      <webElementGuid>95469e0a-83cf-485a-a24c-0de83d6c9eae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div</value>
      <webElementGuid>4030798f-eee5-460c-ae88-06ca75601011</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    
        
        
        
            Account
            
        
        
            
                First name
                
                
            
            
                Last name
                
                
            
        
        
            Email
            
            
        
        
            Gender
            
                
                Male
                Female
            
            
        
        
            Birthday
            
            
        
        
            Address
            
            
        
        
            Website
            
            
        
        
            Update information
        
    
' or . = '
    
        
        
        
            Account
            
        
        
            
                First name
                
                
            
            
                Last name
                
                
            
        
        
            Email
            
            
        
        
            Gender
            
                
                Male
                Female
            
            
        
        
            Birthday
            
            
        
        
            Address
            
            
        
        
            Website
            
            
        
        
            Update information
        
    
')]</value>
      <webElementGuid>9a3028ff-6458-46a6-ba38-bb1223158fb4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
