<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_My profile</name>
   <tag></tag>
   <elementGuidId>3f3a0163-49e3-44f9-bfa6-6b8844f68b46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'My profile')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.dropdown__link</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3ed5653a-a43f-41fd-b33e-c22276327999</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown__link</value>
      <webElementGuid>c2b9d295-9847-4861-b89f-3c6dda4ad126</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/account</value>
      <webElementGuid>d54c605f-df19-495e-9b17-3e7d21d9f15d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>My profile</value>
      <webElementGuid>55fdce1b-3c1e-4d89-997d-5ab08fe64f79</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[@class=&quot;header&quot;]/nav[@class=&quot;container header__nav&quot;]/ul[@class=&quot;header__menu&quot;]/li[@class=&quot;header__item&quot;]/div[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown__menu&quot;]/li[@class=&quot;dropdown__item&quot;]/a[@class=&quot;dropdown__link&quot;]</value>
      <webElementGuid>6bb5b56f-f341-4ea4-88e5-55ceb9e8b468</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'My profile')]</value>
      <webElementGuid>08352d3b-50ae-466d-9629-a99ef70f153e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New post'])[1]/following::a[1]</value>
      <webElementGuid>97fe8cf2-b025-4c4d-9f2b-4af0fa39626b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/preceding::a[1]</value>
      <webElementGuid>74e273ef-9644-4beb-8a9b-7f8ece03b2db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/preceding::a[2]</value>
      <webElementGuid>f9556f86-a6ca-478d-afd3-92e76747fddb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='My profile']/parent::*</value>
      <webElementGuid>e40d1a96-6149-488f-a5c8-f06335aaabb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/account')]</value>
      <webElementGuid>5538923e-ad3e-49dd-89c3-2459d263c0f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li/a</value>
      <webElementGuid>bbc5f929-c757-45a0-842b-cacaa65c3ae4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/account' and (text() = 'My profile' or . = 'My profile')]</value>
      <webElementGuid>c736144b-c631-4d16-af4c-939f525e0ac8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
