<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Sign In                            Ema_6c7101</name>
   <tag></tag>
   <elementGuidId>13558be2-9d39-47f4-b3da-466032c8db09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form.sign-in-form.form</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>b8a0ea32-d01d-4488-913b-c5860d04ed22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sign-in-form form</value>
      <webElementGuid>93f072e0-9655-4cb1-87af-d3ce663776e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>19bcfc8b-005c-487f-9c90-9f7fd05654f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    </value>
      <webElementGuid>536bbd88-7501-4158-a018-22edbe0bb9a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;form-wrapper&quot;]/main[@class=&quot;main&quot;]/div[@class=&quot;container&quot;]/form[@class=&quot;sign-in-form form&quot;]</value>
      <webElementGuid>fe8fab3d-0bcf-458c-aeeb-d8591bb0c482</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='']</value>
      <webElementGuid>618e20d1-61d8-4be5-a000-e74d3525f892</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>139419db-3348-4c56-a6ef-d0d7adbd21eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    ' or . = '
        
        
            Sign In
        
        
            Email
            
            
        
        
            Password
            
            
        
        
            Forgot password?
        
        
            
                Sign in
            
        
        New to Universe?
        Sign up
    ')]</value>
      <webElementGuid>c0e4d72d-c86e-40c0-8590-31fe54048234</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
