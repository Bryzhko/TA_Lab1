<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Read more</name>
   <tag></tag>
   <elementGuidId>9ee6365a-8b66-4b92-b073-a7445db77503</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.card__button.button.button--primary</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Read more')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5d7fa1ff-b87f-4887-a607-d5319d2a2a13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card__button button button--primary</value>
      <webElementGuid>1491b524-d0e3-4aa9-a3d4-62659cd19229</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/posts/33</value>
      <webElementGuid>ff7e0ac1-657c-4685-a04e-53f873f6b5ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Read more</value>
      <webElementGuid>8e8ce9fa-7469-43fc-9362-4454931d398f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;cards&quot;]/div[@class=&quot;card&quot;]/a[@class=&quot;card__button button button--primary&quot;]</value>
      <webElementGuid>a52da5f5-1f46-4bc6-b5d0-f5bcad930471</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Read more')]</value>
      <webElementGuid>d978ddb8-07c3-4b0a-9ac3-deac23b5342a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='lslsls'])[1]/following::a[1]</value>
      <webElementGuid>7721555f-677e-484a-91cc-acd571075e78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign out'])[1]/following::a[1]</value>
      <webElementGuid>ef00339a-00e3-4fa6-b319-f6ee7971e757</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Abracadabra3535'])[1]/preceding::a[1]</value>
      <webElementGuid>2b721b88-ddb3-4b57-8bd7-ff9119012477</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read more'])[2]/preceding::a[1]</value>
      <webElementGuid>b1e45b81-af51-48f7-b18f-1cec226cd9a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Read more']/parent::*</value>
      <webElementGuid>cf1d7c56-99cf-4cf7-9498-4acd7ecab1df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/posts/33')]</value>
      <webElementGuid>16b94cbb-0b96-453d-9483-55a332b7aa52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/a</value>
      <webElementGuid>a3c6e98f-1b96-4816-b8c7-48202164faa6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/posts/33' and (text() = 'Read more' or . = 'Read more')]</value>
      <webElementGuid>1c36ca08-1c85-4e26-a171-1cb19b2436d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
