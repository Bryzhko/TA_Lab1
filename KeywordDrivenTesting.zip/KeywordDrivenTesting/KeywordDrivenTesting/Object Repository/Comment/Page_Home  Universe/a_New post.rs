<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_New post</name>
   <tag></tag>
   <elementGuidId>bfe4fe9f-53ad-4e46-b3db-255800af02e5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.header__link.header__link--primary.button</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'New post')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6156ac47-1b21-41a3-bbda-3cd92c0644dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header__link header__link--primary button</value>
      <webElementGuid>00893e18-be2d-46cc-b267-173ef744da80</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/posts/create</value>
      <webElementGuid>033c90c6-3376-4939-9da2-2976d9c21ec2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New post</value>
      <webElementGuid>cdac0ec4-d48b-4163-bcbd-72566d326cb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[@class=&quot;header&quot;]/nav[@class=&quot;container header__nav&quot;]/ul[@class=&quot;header__menu&quot;]/li[@class=&quot;header__item&quot;]/a[@class=&quot;header__link header__link--primary button&quot;]</value>
      <webElementGuid>e6408ac8-004c-4a42-8100-d316fd9931b5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'New post')]</value>
      <webElementGuid>aa8a3821-10f3-44b7-8beb-7508efa397df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My profile'])[1]/preceding::a[1]</value>
      <webElementGuid>cbeb7f32-8942-4aaf-92f1-51879a5f957d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/preceding::a[2]</value>
      <webElementGuid>80919a0f-e48e-4a8d-a4f9-ae892101dcd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New post']/parent::*</value>
      <webElementGuid>8adc7120-2b6a-4820-90fb-021e75b84ff1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/posts/create')]</value>
      <webElementGuid>4c04d55b-7010-4794-868a-0fa4f9fdd331</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a</value>
      <webElementGuid>39ac06c8-61b9-45d1-8fbf-298f838d8b52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/posts/create' and (text() = 'New post' or . = 'New post')]</value>
      <webElementGuid>47cba1ed-8e07-49f3-b475-3ee5070d7bda</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
