<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_this is comment for the post</name>
   <tag></tag>
   <elementGuidId>55dc2b14-4108-411b-82eb-06711ddf11ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.comment__description</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='dbgfd gdhdf'])[2]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>e8daed20-efbd-4266-b361-d64285b5fd10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>comment__description</value>
      <webElementGuid>7a8da01f-745b-4793-98d9-cf0e2b3d2dc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>this is comment for the post</value>
      <webElementGuid>5c96c443-5bc7-47da-93f6-74ea487a1a87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[@class=&quot;main&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;post-wrapper&quot;]/div[@class=&quot;comments&quot;]/div[@class=&quot;comment&quot;]/p[@class=&quot;comment__description&quot;]</value>
      <webElementGuid>83a43cc7-b3eb-4b07-92a7-29622b365905</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='dbgfd gdhdf'])[2]/following::p[1]</value>
      <webElementGuid>096253e7-8cf7-44b6-943c-2e3541de28a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='lslsls'])[1]/following::p[2]</value>
      <webElementGuid>d5d1afd1-c1c5-4a03-8bf9-90c9917a24e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reply'])[1]/preceding::p[1]</value>
      <webElementGuid>d2fffeed-436b-410e-9653-8605f2e38764</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='May 29, 2023 20:57:10'])[1]/preceding::p[1]</value>
      <webElementGuid>78550844-2ea7-4ac9-aa0b-b4761fcd1610</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='this is comment for the post']/parent::*</value>
      <webElementGuid>d548b4f3-d246-406a-9cf9-51cefa12bbda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/p</value>
      <webElementGuid>40a8aafa-edfc-453b-a2d5-543f88c68af4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'this is comment for the post' or . = 'this is comment for the post')]</value>
      <webElementGuid>38a05d33-d41e-419c-b975-378b3b38156e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
